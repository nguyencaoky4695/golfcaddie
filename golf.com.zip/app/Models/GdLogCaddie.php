<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GdLogCaddie extends Model
{
    protected $table = 'gd_log_caddie';
}
