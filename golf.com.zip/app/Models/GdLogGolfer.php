<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GdLogGolfer extends Model
{
    protected $table = 'gd_log_golfer';
}
